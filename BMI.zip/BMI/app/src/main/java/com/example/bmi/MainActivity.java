package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText textBeratBadan;
    private EditText textTinggiBadan;
    private EditText txtHasil;
    private Button btnHitung;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textBeratBadan = (EditText) findViewById(R.id.textBeratBadan);
        textTinggiBadan =(EditText) findViewById(R.id.textTinggiBadan);
        txtHasil=(EditText) findViewById(R.id.txtHasil);
        btnHitung=(Button)findViewById(R.id.btnHitung);

    }
    public void hitungLuas (View view){
        try {
            double beratBadan=Double.parseDouble(textBeratBadan.getText().toString());
            double tinggiBadan=Double.parseDouble(textTinggiBadan.getText().toString());
            double hasil = (beratBadan / tinggiBadan * tinggiBadan );
            txtHasil.setText(String.valueOf(hasil));
        }catch (Exception e){
            e.printStackTrace();
        }


    }


}
